<?php 
	include($_SERVER['DOCUMENT_ROOT'].'/your_videos_channel/includes/variables.php'); 
	$connect->set_charset('utf8');
	
?>